package com.data_flair.dto;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.HashMap;
import java.util.Map;

@Configuration
@PropertySource("classpath:profile.properties")
//@ConfigurationProperties(prefix = "app")
public class ProfileConfig {

    @Value("${firstname}")
    private String firstname;

    @Value("${lastname}")
    private String lastname;

    @Value("${email}")
    private String email;

    @Value("${mobile}")
    private String mobile;

    @Value("${location}")
    private String location;

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Map getProperties() {
        Map map = new HashMap();
        map.put("firstname", firstname);
        map.put("lastname", lastname);
        map.put("email", email);
        map.put("mobile", mobile);
        map.put("location", location);
        return map;
    }
}
