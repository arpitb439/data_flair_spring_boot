package com.data_flair.dto;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class AppConfig {

    @Value("${app.name}")
    private String appName;

    @Value("${app.version}")
    private String appVersion;

    @Value("${app.author}")
    private String appAuthor;

    public Map printConfig() {
        Map map = new HashMap();
        map.put("appName", appName);
        map.put("appVersion", appVersion);
        map.put("appAuthor", appAuthor);
        return map;
    }
}