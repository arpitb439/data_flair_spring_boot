package com.data_flair.controller;

import com.data_flair.dto.AppConfig;
import com.data_flair.dto.AppProperties;
import com.data_flair.dto.ProfileConfig;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class TestController {

    private final AppConfig appConfig;
    private final AppProperties appProperties;
    private final ProfileConfig profile;

    public TestController(AppConfig appConfig, AppProperties appProperties, ProfileConfig profile) {
        this.appConfig = appConfig;
        this.appProperties = appProperties;
        this.profile = profile;
    }

    @GetMapping("/test1")
    public Map<String, String> test1() {
        return appConfig.printConfig();
    }

    @GetMapping("/test2")
    public Map<String, String> tes2() {
        return appProperties.printConfig();
    }

    @GetMapping("/test3")
    public Map<String, String> tes3() {
        return profile.getProperties();
    }
}
