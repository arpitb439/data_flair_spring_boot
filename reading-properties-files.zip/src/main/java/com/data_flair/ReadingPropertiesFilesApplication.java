package com.data_flair;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadingPropertiesFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadingPropertiesFilesApplication.class, args);
	}

}
