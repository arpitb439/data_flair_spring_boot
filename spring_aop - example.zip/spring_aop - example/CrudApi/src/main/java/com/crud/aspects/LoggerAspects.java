package com.crud.aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggerAspects {

    private static Logger logger = LoggerFactory.getLogger(LoggerAspects.class);

    @Before("execution(* com.crud.controller.UserController.testAop(..))")
    public void beforeMethodExample(JoinPoint joinPoint) {
        logger.info("beforeMethodExample");
    }

    @After("execution(* com.crud.controller.UserController.testAop(..))")
    public void afterMethodExample(JoinPoint joinPoint) {
        logger.info("AfterMethodExample :: " + joinPoint.getSignature().getName());
    }

    @Around("execution(* com.crud.controller.UserController.testAop(..))")
    public Object aroundMethodExample(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        logger.info("Before calling :: " + proceedingJoinPoint.getSignature().getName());
        Object result = proceedingJoinPoint.proceed();
        logger.info("After calling :: " + proceedingJoinPoint.getSignature().getName());
        return result;
    }

}
