package com.crud.controller;

import com.crud.request.UserRequest;
import com.crud.request.UserUpdateRequest;
import com.crud.response.UserResponse;
import com.crud.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public List<UserResponse> getAll() {
        return userService.getAll();
    }

    @GetMapping("/{userId}")
    public UserResponse getUser(@PathVariable("userId") int userId) {
        return userService.getUserById(userId);
    }

    @PostMapping
    public UserResponse createUser(@RequestBody UserRequest userRequest) {
        return userService.createUser(userRequest);
    }

    @PutMapping
    public UserResponse updateUser(@RequestBody UserUpdateRequest updateRequest) {
        return userService.updateUser(updateRequest);
    }

    @DeleteMapping("/{userId}")
    public void deleteUser(@PathVariable int userId) {
        userService.deleteUser(userId);
    }

    @GetMapping("/aop")
    public String testAop() {
        userService.testAop();
        return "success";
    }

}
