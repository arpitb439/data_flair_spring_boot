package com.data_flair.first_project.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class EmployeeRegistrationDto {

    @NotNull(message = "First name must not be null")
    @NotBlank(message = "First name must not be blank")
    String firstName;

    @NotNull(message = "Last name must not be null")
    @NotBlank(message = "Lat name must not be blank")
    String lastName;

    String email;

    @NotNull(message = "Mobile must not be null")
    @NotBlank(message = "Mobile must not be blank")
    @Size(min = 10, max = 12, message = "Mobile number must contain 10-12 digits")
    String mobile;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
