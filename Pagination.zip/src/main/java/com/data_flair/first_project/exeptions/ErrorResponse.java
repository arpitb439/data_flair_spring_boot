package com.data_flair.first_project.exeptions;

import java.time.LocalDateTime;

public class ErrorResponse {

    private int statusCode;
    private String message;
    private LocalDateTime occurredAt;
    private String customeMessage;

    public ErrorResponse(String message) {
        super();
        this.message = message;
    }

    public ErrorResponse(int statusCode, String message, LocalDateTime occuredAt, String customeMessage) {
        this.statusCode = statusCode;
        this.message = message;
        this.occurredAt = occuredAt;
        this.customeMessage = customeMessage;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getOccuredAt() {
        return occurredAt;
    }
    public void setOccuredAt(LocalDateTime occuredAt) {
        this.occurredAt = occuredAt;
    }

    public String getCustomeMessage() {
        return customeMessage;
    }

    public void setCustomeMessage(String customeMessage) {
        this.customeMessage = customeMessage;
    }
}