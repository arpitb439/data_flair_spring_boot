package com.data_flair.first_project.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        Map<String, Object> extensions = new LinkedHashMap<>();
        extensions.put("Company", "ProgrammingPulse");
        return new OpenAPI().info(new Info().title("Data Flair").version("1.0").description("Spring Boot Learning").contact(new Contact().name("Arpit").email("arpitb439@gmail.com")).license(new License().name("Apache 2.0").extensions(extensions)));
    }
}