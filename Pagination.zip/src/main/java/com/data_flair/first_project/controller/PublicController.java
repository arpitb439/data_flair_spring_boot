package com.data_flair.first_project.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public")
@Tag(name = "Public API", description = "Other public APIs")
public class PublicController {

    @GetMapping("/hello")
    public String sayHello() {
        return "Hello World";
    }
}
