package com.data_flair.first_project.controller;

import com.data_flair.first_project.entities.Employee;
import com.data_flair.first_project.request.EmployeeRegistrationDto;
import com.data_flair.first_project.response.BaseResponse;
import com.data_flair.first_project.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/employees")
@Tag(name = "Employee API", description = "Operations related to employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/all")
    @Operation(summary = "Employee List")
    public BaseResponse getAllEmployees() {

        List<Employee> employees = employeeService.getAllEmployees();
        if (employees.isEmpty()) {
            return new BaseResponse(204, "No data found", null);
        }
        return new BaseResponse(200, "Employees records fetched successfully", employees);
    }


    @GetMapping("/pagination")
    public Page<Employee> getUsers(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "5") int size) {

        return employeeService.getUsers(page, size);
    }

    @GetMapping("/getById/{id}")
    @Operation(summary = "Get employee by id")
    public BaseResponse getEmployeeById(@PathVariable("id") int id) {

        Optional<Employee> optionalEmployee = employeeService.getEmployeeById(id);

        if (optionalEmployee.isPresent()) {
            return new BaseResponse(200, "Employee data fetched", optionalEmployee.get());
        } else {
            return new BaseResponse(204, "No record found for id " + id, null);
        }
    }

    @GetMapping("/getById-ex/{id}")
    @Operation(summary = "Get employee by id(exception handling)")
    public Employee getEmployeeByIdExceptionHandeling(@PathVariable("id") int id) {
        return employeeService.getEmployeeByIdException(id);
    }

    @PostMapping("/registration")
    @Operation(summary = "Employee Registration")
    public ResponseEntity<BaseResponse> employeeRegistration(@Valid @RequestBody EmployeeRegistrationDto employeeRegistrationDto, BindingResult bindingResult) {

        // validate reqest
        if (bindingResult.hasErrors()) {
            Set<String> errors = bindingResult.getFieldErrors().stream().map(error -> error.getDefaultMessage()).collect(Collectors.toSet());
            return ResponseEntity.status(400).body(new BaseResponse(400, "Please check input values", errors));
        }

        // call service
        return ResponseEntity.status(200).body(employeeService.saveEmployee(employeeRegistrationDto));
    }
}
