package com.data_flair.first_project.service;

import com.data_flair.first_project.entities.Employee;
import com.data_flair.first_project.exeptions.NoSuchCustomerExistsException;
import com.data_flair.first_project.repo.EmployeeRepository;
import com.data_flair.first_project.request.EmployeeRegistrationDto;
import com.data_flair.first_project.response.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Page<Employee> getUsers(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return employeeRepository.findAll(pageable);
    }

    public Optional<Employee> getEmployeeById(int id) {
        return employeeRepository.findById(id);
    }

    public Employee getEmployeeByIdException(int id) {
        return employeeRepository.findById(id).orElseThrow(() -> new NoSuchCustomerExistsException("NO CUSTOMER PRESENT WITH ID = " + id));
    }

    public BaseResponse saveEmployee(EmployeeRegistrationDto dto) {
        Employee employee = new Employee();
        employee.setFirstName(dto.getFirstName());
        employee.setLastName(dto.getLastName());
        employee.setEmail(dto.getEmail());
        employee.setMobile(dto.getMobile());

        Employee savedEmp = null;
        try {
            savedEmp = employeeRepository.save(employee);
        } catch (Exception e) {
            return new BaseResponse(500, "Error in saving employee information", e.getMessage());
        }
        return new BaseResponse(200, "Employee registration is successfully done", savedEmp);
    }

}
