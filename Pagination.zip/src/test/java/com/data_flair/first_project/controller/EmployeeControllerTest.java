package com.data_flair.first_project.controller;

import com.data_flair.first_project.entities.Employee;
import com.data_flair.first_project.request.EmployeeRegistrationDto;
import com.data_flair.first_project.response.BaseResponse;
import com.data_flair.first_project.service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmployeeService employeeService;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void testGetAllEmployees() throws Exception {

        Employee emp1 = new Employee(1,"John","Doe","john@gmail.com","9999999999");
        Employee emp2 = new Employee(2,"Jane","Smith","jane@gmail.com","8888888888");

        Mockito.when(employeeService.getAllEmployees())
                .thenReturn(Arrays.asList(emp1, emp2));

        mockMvc.perform(get("/employees/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("Employees records fetched successfully"));
    }

    @Test
    void testGetEmployeeById() throws Exception {

        Employee emp = new Employee(1,"John","Doe","john@gmail.com","9999999999");

        Mockito.when(employeeService.getEmployeeById(1))
                .thenReturn(Optional.of(emp));

        mockMvc.perform(get("/employees/getById/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Employee data fetched"));
    }

    @Test
    void testEmployeeRegistration() throws Exception {

        EmployeeRegistrationDto dto = new EmployeeRegistrationDto();
        dto.setFirstName("John");
        dto.setLastName("Doe");
        dto.setEmail("john@gmail.com");
        dto.setMobile("9999999999");

        BaseResponse response =
                new BaseResponse(200,"Employee registration is successfully done",null);

        Mockito.when(employeeService.saveEmployee(Mockito.any()))
                .thenReturn(response);

        mockMvc.perform(post("/employees/registration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message")
                        .value("Employee registration is successfully done"));
    }
}