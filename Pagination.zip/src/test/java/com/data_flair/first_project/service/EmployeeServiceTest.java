package com.data_flair.first_project.service;

import com.data_flair.first_project.entities.Employee;
import com.data_flair.first_project.repo.EmployeeRepository;
import com.data_flair.first_project.request.EmployeeRegistrationDto;
import com.data_flair.first_project.response.BaseResponse;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private EmployeeService employeeService;

    @Test
    void testGetAllEmployees() {

        Employee emp1 = new Employee();
        emp1.setFirstName("John");

        Employee emp2 = new Employee();
        emp2.setFirstName("Jane");

        Employee emp3 = new Employee();
        emp3.setFirstName("Irfan");
    // Defines behaviours
        Mockito.when(employeeRepository.findAll())
                .thenReturn(Arrays.asList(emp1, emp2, emp3));

        assertEquals(3, employeeService.getAllEmployees().size());
    }

    @Test
    void testGetEmployeeById() {

        Employee emp = new Employee();
        emp.setId(1);

        Mockito.when(employeeRepository.findById(1))
                .thenReturn(Optional.of(emp));

        Optional<Employee> result = employeeService.getEmployeeById(1);

        assertTrue(result.isPresent());
        assertEquals(1, result.get().getId());
    }

    @Test
    void testSaveEmployee() {

        EmployeeRegistrationDto dto = new EmployeeRegistrationDto();
        dto.setFirstName("John");
        dto.setLastName("Doe");
        dto.setEmail("john@gmail.com");
        dto.setMobile("9999999999");

        Employee savedEmployee = new Employee();
        savedEmployee.setId(1);

        Mockito.when(employeeRepository.save(Mockito.any()))
                .thenReturn(savedEmployee);

        // when i pass null then throw NullPointerException
        // Assert(NullPointerException, 0)

        BaseResponse response = employeeService.saveEmployee(dto);

        assertEquals(200, response.getStatusCode());
        assertEquals("Employee registration is successfully done", response.getMessage());
    }
}