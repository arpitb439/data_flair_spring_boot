package com.data_flair.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    public void processUser() {

        logger.trace("TRACE: Entered processUser()");
        logger.debug("DEBUG: Processing user logic");

        logger.info("INFO: User processing started");

        try {
            int result = 10 / 2;
            logger.info("INFO: Calculation result = {}", result);
        } catch (Exception e) {
            logger.error("ERROR: Exception occurred", e);
        }

        logger.warn("WARN: This is just a warning message");
    }
}