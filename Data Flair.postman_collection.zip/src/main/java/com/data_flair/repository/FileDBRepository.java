package com.data_flair.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.data_flair.model.FileDB;

@Repository
public interface FileDBRepository extends JpaRepository<FileDB, String> {

}
