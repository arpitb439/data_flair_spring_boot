package com.data_flair.services.impl;

import com.data_flair.entities.Person;
import com.data_flair.repositories.PersonRepository;
import com.data_flair.services.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.Duration;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonRepository repository;

    @Override
    public Mono<Person> create(Person person) {
        Mono<Person> createdPerson = repository.save(person);
        return createdPerson;
    }

    @Override
    public Flux<Person> getAll() {
        return repository.findAll().delayElements(Duration.ofSeconds(3));
    }

    @Override
    public Mono<Person> get(int pId) {
        Mono<Person> item = repository.findById(pId);
        return item;
    }

    @Override
    public Mono<Person> update(Person p, int id) {
        Mono<Person> oldPerson = repository.findById(id);
        return oldPerson.flatMap(p1 -> {
            p1.setName(p.getName());
            p1.setCity(p.getCity());
            p1.setEmail(p.getEmail());
            p1.setMobile(p.getMobile());
            return repository.save(p1);
        });
    }

    @Override
    public Mono<Void> delete(int id) {

        return repository.findById(id).flatMap(p -> repository.delete(p));
    }

    @Override
    public Flux<Person> search(String query) {
        return null;
    }

}
