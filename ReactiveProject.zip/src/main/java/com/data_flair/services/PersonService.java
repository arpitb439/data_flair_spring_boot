package com.data_flair.services;

import com.data_flair.entities.Person;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface PersonService {

    public Mono<Person> create(Person p);

    public Flux<Person> getAll();

    public Mono<Person> get(int pId);

    public Mono<Person> update(Person p, int pId);

    public Mono<Void> delete(int pId);

    public Flux<Person> search(String query);

}
