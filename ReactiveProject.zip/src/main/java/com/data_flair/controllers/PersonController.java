package com.data_flair.controllers;

import com.data_flair.entities.Person;
import com.data_flair.services.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/persons")
public class PersonController {

    @Autowired
    private PersonService service;

    @PostMapping
    public Mono<Person> create(@RequestBody Person person) {
        return service.create(person);
    }

    @GetMapping
    public Flux<Person> getAll() {
        return service.getAll();
    }

    @GetMapping("/{pid}")
    public Mono<Person> get(@PathVariable("pid") int pId) {
        return service.get(pId);
    }

    @PutMapping("/{pId}")
    public Mono<Person> update(@RequestBody Person p, @PathVariable int pId) {
        return service.update(p, pId);
    }

    @DeleteMapping("/{pId}")
    public Mono<Void> delete(@PathVariable int pId) {
        return service.delete(pId);
    }

}
