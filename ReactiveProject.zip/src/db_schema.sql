CREATE TABLE person_details(
                             p_id INT PRIMARY KEY  AUTO_INCREMENT,
                             NAME VARCHAR(255),
                             MOBILE VARCHAR(255),
                             EMAIL VARCHAR(255),
                             CITY VARCHAR(255)
)