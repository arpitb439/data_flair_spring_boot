package com.dataflair.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class HelloWorldController {

    @GetMapping({"/hello"})
    public String firstPage() {
        return "Hello World";
    }

    @GetMapping("/test")
    public String test() {
        return "Controller working";
    }

}